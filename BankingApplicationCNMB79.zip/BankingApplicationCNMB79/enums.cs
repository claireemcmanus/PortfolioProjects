public enum AccountType { Savings, Checking }
public enum LoanType { Home, Auto, Personal, None }
public enum JobTitle { Manager, LoanOfficer }

